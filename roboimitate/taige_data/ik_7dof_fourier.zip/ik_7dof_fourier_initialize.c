/*
 * File: ik_7dof_fourier_initialize.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 07-Oct-2023 11:12:14
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ik_7dof_fourier.h"
#include "ik_7dof_fourier_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void ik_7dof_fourier_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for ik_7dof_fourier_initialize.c
 *
 * [EOF]
 */
