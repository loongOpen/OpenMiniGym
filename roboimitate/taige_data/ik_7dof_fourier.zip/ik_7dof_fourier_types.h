/*
 * File: ik_7dof_fourier_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 07-Oct-2023 11:12:14
 */

#ifndef IK_7DOF_FOURIER_TYPES_H
#define IK_7DOF_FOURIER_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for ik_7dof_fourier_types.h
 *
 * [EOF]
 */
