/*
 * File: _coder_ik_7dof_fourier_info.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 07-Oct-2023 11:12:14
 */

/* Include Files */
#include "_coder_ik_7dof_fourier_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[24] = {
    "789ced5dcd6f1cb7151fc5b29a22769b1601f28924eac1b06140933a405b384020c7b122a592adc472aad43056b3bb5c8bd17c6c6666950d7a59e450e498638e"
    "fd077acf298702e929c7163d35e8a540af4582b4455b20e47c6866a991c81d92bb9cd55b60213d891feff1bddfbc47f291632d6c6c59e4f303f2fdf891056b89",
    "fc7c947c1fb1d2cff98c5e20df7bd9cff4ef8bd6c58cfe887c3b811fa3619cfed3773c64e59f6ee061dff1e39d0ffbc80a5114b887a89bfca7875db4833db419"
    "9488754c086fadf4af2382fe2bdc8f8e5ab6dc32917ea81c7df2cde558ac90e3d5921c8f67f4fd5b0f5ebf6e7b4eec3aed5f05e141d4773ac87e2374ba032746",
    "f6cfbb41af75d0ea05038c421b1fb4923f103224f48a97f6fb12a7df7363fd9e23631625f57ec1a9b7c4f0bb948ceaa0eda2b4df21a7fe1b4c7d4adfdfd8dcbd"
    "f5e0e6757b3b0c1e868ef7221de4c8debab1b379e335fbed6b2ffdf4678e1d0781db0e8636f25cdbc5ed6c786ce4f606be4db82782b3fc2f55f4bf50eafffbd9",
    "dfc9e7e2e54b7fbe21513ff99850ff72a9fe42457dabf4b34ef959eb779bd3ffd34cff94ee045d020c4c1e0aa1efb82b51c7719d70855a7c21d76978c93fe576"
    "f37a1f73f8b9cbd4bb5b673ce8f76a22857d3517c3be9aca918d4dce4f3dfb197d7be569b0ff26d8ff1ea7ff2b4cff9466ecdfe9f7dd0fef26c6b336f03b310e",
    "fc0d7fdb253ea624e72aa79f1f32fd50ba97b5d6da77fc2e7108b49d4f39edb49976da75c6ab121f278b99c145c6de3effe3cb801791f2a6eb5f973f918da3c0"
    "af141f13eaebc64953e60911f61b3c4f20dcc33c618ee3a442bfea9eebd4e20bb99a3b4f48c726e7079ee7f36dff7b9cfe619e00f30493f062bafe75f993e6cf",
    "13c0af94ebcfeb3c8167a7e7997e29dd098328aa18d73a763ee2d4ff25539fd232fe34eaa34eb2f2466590b7efff837d9b6ddfbc79f0e258bf8b961f84de34ec"
    "7a83a94f6919bb263fa85953f673f72663d77fbfbc05762d527e6499a1675e1cf302c307a599380647af0db01b6ff8b7071e0a71672a71cc2e537fb7cef854c6",
    "31ac382bc7703d813d3df5ed977f023c0894e7e9fb6d6b5cdf94568687e587c8efd35f0b7e0017800bc0c5e4b81098f7b65d275a19faa177ed043d346cde4be5"
    "b11379e4e7055fbf7700f1930a5c4c5bdf3c5c3cc3f043e92a5c60dfc53e2ae4d4b5bfb0c3d4db513c3ea91ce90049d8d3d25723f013f3880781f829c1c32042",
    "ad10f5e8ef5278f884c3cfbb4cbd77158f4f490e05f36cc0c5bce2e239861f4a33b8c8cde828849a46fcf40e53ff1d75e394c9530c95845dc1be81607993f55d"
    "c5cff7187e281d22c7f5b2fca349d76b3bfb4e388b7d04e4925fec8c73e9f982f55fb077b1f223cb0c3daf72f8788ce183d2a4e9566eeb793b75ed9d87fb93d6",
    "8fb6e506a21fe243baf75212456afd08ec5eb0bc69fa56b07ed4730327de227f734b72eac28392f5b54a3f5888219f5704f9124d8d7b14e001fb5d34dcc2fe60"
    "9ae70df4e1a2104741bedda57f44304f3ecbb8a067b3cbb858e7b4fb24d3ee9327b4bbe1c726e024110f7052d43f6b38e1d9f3530c3f94aeb2e76d7710cd021f",
    "6f31edbda56cbc8ec452b1de0af8102c6f1a3e787ee479861f4ad3490b69b6d50b423708faade01085245affa0d5d9479d03b97d39de3ec41e536fafcef894a7"
    "63e9709d228fcc3c7c04f370c1f29f59a7ebfdb7d6b8de29ad5befcba71768ed23b78fc27af36b1cf5b00e7fc23b47b5c6b4b756771c7b7888bafd8070615359",
    "24f725fe0338112b3f6bfdae72fabfc8f44f691cf9694a5c4caf91925b8f1a71eadd61fabfa344fe12ff72e7a1c1ce05cb37dd1fd4595f224d7bce502f3ede64"
    "fa7d5376dc92e5ec947305f36c889704cb9f557cd02dbe66e2e3689b13f0619dbd79f6a4f7c638ed26df2f49b8978a934617e0de1835f301ddfa857340700e08",
    "70a0f2be0bfae42fe46aeefd49e9d8e4fcd4f4037ffdfd75f0034db0ff5d4eff3f61faa734fffea442be554efba2f726f1f617ee33eddcaf334ea2f7e6c8e3e3"
    "2f705f92587953f5aecb6f34f8bc28f88f8afabaf161ea3d498f32fd52da0bbbf81077910a3b1f71eaab5e0f0afa919df3bfd22fc6bfa67d5c58fddd4ced5bd9",
    "3d4dbaed7b6499a767e1733c69334a9eebbc71507daf0e1d877c1814dc9ff49b7f6ec3f35c85bd4f4bcfb03e04eb438087820f1e1e5e64f8a07445bc8f86fd9b"
    "81d777624c2c5a051e6677feff98382af251ff05fb64cdc2c53a878f1f337c509ac10569b57adc75c4494acec356e28188213fef8d204e122b6feabcb7ca3ebd",
    "7ef0814cfec424fbc2eb4c7d4a4bcf8712fea5f2a9ff07cf75b1f2b3d62fc4fd10f7030eeaad6fe2883416e2e134e2984da6fea6a4fc59be5b2681f4fd7690ef"
    "2658de743b3fcff44fe92c9c69649e1b953f135f264effe60b88d395d8b76efd423c03f18c09381859a7eb7bdb1ad737a515e160b9e7c6c9af22eb3502e716d3",
    "7dfe5b0fa7b25ea3645c4e5cbfa46248d9ffbfff7007fc8031f62fa0e7550e1fa2e72075db3d9c8704bbd7f57c139fcff6307127fb8dcad761ce3f53fe159cdf"
    "027b172c3fbbb8b6b0f7e51e0ea338bda701ee49817b520017c77151f7de13ddeb3d6b4cfdb53ae300f79c9c587f2ee21d81792e9c6b81732d26e3c454bdf3e2",
    "a56719be285d9de776c375834ea53e74ac97ea7bef53591ce97d31c86f132c6f9abe15f89372c3b7839be95ca24a1f3af240f53d4f2ac492f7237fbbbd083851"
    "e1477e6d8deb9dd2aae2ad7466d14a2efc6fe59bc296585e28ec33c03ec32cf0f0c01ad733a555cf3f5addc073b0df42611888e64954e559e0c8777cc1fab2f6",
    "af3a5f3ccf272212a8381700eb4c82e54796197a86bc0bc8bb30010ff3e40f48a0255cdf3c7f40ef9d492450e10f2ec23d73a6fa836a3d833f007f007828f850"
    "b4ceea842bb95790db97e6e1e01e53ef5e9d7139f5dea0628c24d68de07d8182e547961938d8e3f07185e183d2fc7dba0d7fdb753aa8d4cf2aa71fd1fdba4f39",
    "edb49976da75c64d74df261353417ed3e7b06f2756de74fdebf22bbae32cf02ff385939175babe4d39eff004c307a5193ce4d3766e7cb5601dcf9b127d7fc116"
    "c3c7569df1a8b4ff847d59bbffe21504762f527e56f752f0ecfc474cbf94a679a15e4cdfb47af48a8f233974cd2394dc3fcae0fe981cf2fbcf705f8560795e3c",
    "e458e3faa6b4067d2f7702cf23917a92d15cbe4f17d69d60ddc9049c98f65ce4f90bc8cf98c88e203f43b0bc6938e0f907817bdce94ba356860f91575ed7aa3b"
    "4f98caf854cf93d3975f5139e4e3a7c32f3f023c18838709f4cdc3c3330c3f94aec203f65deca3424e5df3097d79c0e9f8a47248e77d2f7d358238691ef12030",
    "7f48f03088502b7bc1a0141e78f92cfaeefb4dc7a724878a3c0ec0856079d37001f307983f000ef8fee139861f4a3338c81fa74753089df38769bc3f371f2289"
    "f9c3d7ef1d001e44cacf6abf6152fb8cde0f6315cf79defd01eb4c7d4acbe7ad50eea59eef90af2a587ed6fa55f03cc7d1eb49bef7adf2bef12aa75dd1fc23de",
    "f35d5f1ec5985892fbc9d6a557000f8dc0032fce87fc09c89f98277b57b0fe99e5cfd1360bb91ab8fe99e5cda56393f3037973f36dff7b9cfe211f1bf2b14dc2"
    "8be9fad7e54f9a7b9f12f81558273a39de773a41d4dc7522cabdd47daa17609dc8e438a9d02fac13c13a11e0a1c0c33aa77f58278275a279b27775713d6db390",
    "abb9eb44e9d8e4fc40fc33dff6bfc7e91fd689609dc824bc98ae7f5dfea4f9eb44e057caf575e3c4d475a27363fd9eb39c76a4c4be797e54f5fb49333fda8ee4"
    "de3f0bf62c587e56f6ccb3cbf34cbf947662c7bf5631aecdb9df319100ee772cd5d76ddf23cb0c3daf73f880f30013d90f9c07102c3fb2ccb07f5efc2e7eef56",
    "ee05f4ae07e9bf6fab1823d8df3d3b38d8e5f001ef5d83f7aecd1227a6ea5d97ffd0bdfe037e647ef0f11d59f8847d",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 66200U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[4] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 4, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 7);
  emlrtSetField(xEntryPoints, 0, "Name", mxCreateString("ik_7dof_fourier"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", mxCreateDoubleScalar(7.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", mxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", mxCreateString("9.0.0.341360 (R2016a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_ik_7dof_fourier_info.c
 *
 * [EOF]
 */
