/*
 * File: ik_7dof_fourier_terminate.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 07-Oct-2023 11:12:14
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "ik_7dof_fourier.h"
#include "ik_7dof_fourier_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void ik_7dof_fourier_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for ik_7dof_fourier_terminate.c
 *
 * [EOF]
 */
