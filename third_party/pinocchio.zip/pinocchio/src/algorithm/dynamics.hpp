//
// Copyright (c) 2018 INRIA
//

#ifndef __pinocchio_dynamics_hpp__
#define __pinocchio_dynamics_hpp__

#pragma message("The file pinocchio/algorithm/dynamics.hpp is now deprecated. Please use pinocchio/algorithm/contact-dynamics.hpp instead.")

#include "pinocchio/algorithm/contact-dynamics.hpp"

#endif // ifndef __pinocchio_dynamics_hpp__
