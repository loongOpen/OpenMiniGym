//
// Copyright (c) 2019 INRIA
//

#ifndef __pinocchio_core_unary_op_hpp__
#define __pinocchio_core_unary_op_hpp__

namespace pinocchio
{
  
}

#endif // ifndef __pinocchio_core_unary_op_hpp__

