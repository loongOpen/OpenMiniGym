//
// Copyright (c) 2015-2020 CNRS INRIA
//

#ifndef __pinocchio_python_parsers_srdf_hpp__
#define __pinocchio_python_parsers_srdf_hpp__

namespace pinocchio
{
  namespace python
  {
    void exposeSRDFParser();
  }
}

#endif // ifndef __pinocchio_python_parsers_srdf_hpp__
