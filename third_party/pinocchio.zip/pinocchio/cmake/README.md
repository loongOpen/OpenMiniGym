Shared CMake submodule
======================

[![Documentation Status](https://readthedocs.org/projects/jrl-cmakemodules/badge/?version=master)](https://jrl-cmakemodules.readthedocs.io/en/master/?badge=master)

This repository is meant to be used as a submodule for any project
from CNRS LAAS/HPP or JRL.

It factorizes CMake mechanisms to provide a uniform look'n feel for
all packages.


Please see the documentation on the [wiki] for more information.

You can also checkout the more complete [documentation] of the modules.

[wiki]: http://github.com/jrl-umi3218/jrl-cmakemodules/wiki

[documentation]: http://jrl-cmakemodules.readthedocs.io/en/master/
