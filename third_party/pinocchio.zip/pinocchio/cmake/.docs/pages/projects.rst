Project specific
****************

Humanoid Path Planner
=====================

These macros are used in packages of the
`Humanoid Path Planner <https://humanoid-path-planner.github.io/hpp-doc/>`_ project.

.. setmode:: hpp

.. cmake-module:: ../../hpp.cmake

.. cmake-module:: ../../hpp/doc.cmake

Stack of Tasks
==============

These macros are used in packages of the
`Stack of Tasks <https://github.com/stack-of-tasks/>`_ project.

.. setmode:: sot
