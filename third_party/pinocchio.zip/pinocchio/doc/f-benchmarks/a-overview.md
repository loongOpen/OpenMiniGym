# Overview of algo with plots
