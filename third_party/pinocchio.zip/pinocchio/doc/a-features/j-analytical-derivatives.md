# Analytical derivatives
