# Kinematic algorithms
