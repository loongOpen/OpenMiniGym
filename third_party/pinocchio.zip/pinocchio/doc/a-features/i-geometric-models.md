# Geometric models

TODO: with related algos
