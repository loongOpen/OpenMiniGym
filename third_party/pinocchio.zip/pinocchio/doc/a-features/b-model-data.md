# Model and data

TODO: just explain the concept of model and data and what they contain. The explanation on how to build and/or load a
model is delayed to the two following pages (explicitely say so from the start). Just use
buildModels::humanoid(model) in the snippets [pending v2.0]

