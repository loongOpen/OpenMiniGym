# Automatic differentiation and source code generation
