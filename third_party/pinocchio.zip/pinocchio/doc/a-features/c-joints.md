# Joints

TODO: Or: Building the model: joints and bodies. Maybe merge this section with previous one?
 @nmansard : I prefer this way of separing models of joint models.
