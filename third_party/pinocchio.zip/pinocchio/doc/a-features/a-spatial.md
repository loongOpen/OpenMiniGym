# Spatial Algebra module
