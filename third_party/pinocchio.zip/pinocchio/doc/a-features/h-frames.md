# Operational frames

TODO: as frames are not necessary to understand the previous sections, it could be a good idea to treat them
separately. Introduce them here together with the related algorithms.
