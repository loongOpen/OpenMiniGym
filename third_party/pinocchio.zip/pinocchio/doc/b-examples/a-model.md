# Loading the model

## Python
\include overview-urdf.py

## C++
\include overview-urdf.cpp
