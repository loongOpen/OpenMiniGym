# QP (normal forces) unilateral contact dynamics (if we can write it concise enough)

## Python
\include qp.py

## C++
\include qp.cpp
