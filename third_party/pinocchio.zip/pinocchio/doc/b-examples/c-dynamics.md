# Computing the dynamics RNEA, bias forces b(q,v), gravity g(q), CRBA M(q)

## Python
\include dynamics.py

## C++
\include dynamics.cpp
