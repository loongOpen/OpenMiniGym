# Code generation

## Python
\include code-generation.py

## C++
\include code-generation.cpp
