# Contact dynamics

## Python
\include contact.py

## C++
\include contact.cpp
