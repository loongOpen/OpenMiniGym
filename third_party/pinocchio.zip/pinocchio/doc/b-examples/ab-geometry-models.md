# Geometry models

## Python
\include geometry-models.py

## C++
\include geometry-models.cpp
