# Display a model using GepettoViewer

\include gepetto-viewer.py

