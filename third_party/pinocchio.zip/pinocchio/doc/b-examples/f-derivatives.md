# Derivatives of the dynamics (with finite diff checking)

## Python
\include derivatives.py

## C++
\include derivatives.cpp
