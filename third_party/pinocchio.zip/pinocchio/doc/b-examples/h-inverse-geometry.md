# Inverse geometry

## Python
\include inverse-geometry.py

## C++
\include inverse-geometry.cpp
