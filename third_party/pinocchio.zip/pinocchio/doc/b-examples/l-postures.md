# Posture generation using derivatives (if we can write it concise enough)

## Python
\include postures.py

## C++
\include postures.cpp
