# Task space inverse dynamics

## Python
\include tsid.py

## C++
\include tsid.cpp
