# Build reduced model

This example shows how to build a reduced robot model from an existing URDF model by fixing the desired joints at a specified position. 

## Python
\include build-reduced-model.py

## C++
\include build-reduced-model.cpp