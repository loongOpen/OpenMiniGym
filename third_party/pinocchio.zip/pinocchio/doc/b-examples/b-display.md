# Load and display a model

Pinocchio does not feature a built-in viewer and you will have to rely on external libraries.
However, Pinocchio offers Python support for a few external tools in order to ease the display of a given model.
Below you will find a list of the different options.


