# Main algorithm

TODO: list taken from SII
