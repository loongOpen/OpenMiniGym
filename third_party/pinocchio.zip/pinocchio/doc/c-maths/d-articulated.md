# Articulated Dynamics

## Kinematic Tree

## Configuration and Velocity

## Geometry

## Kinematics and Jacobian

## Inverse and Direct Dynamics
