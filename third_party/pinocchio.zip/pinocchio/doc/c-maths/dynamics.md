# Dynamics

## Direct Dynamics
