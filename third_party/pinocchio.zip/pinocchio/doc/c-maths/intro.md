# Mathematical formulation

This section describes the mathematical formulation used by Pinocchio, which is the base for Featherstone's algorithms.
