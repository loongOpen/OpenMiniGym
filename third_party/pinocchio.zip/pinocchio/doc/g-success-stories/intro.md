# Success Stories

## List of projects succesfully using pinocchio
- TSID
- HPP
- DDP
- Supaero class
- WAN demonstration
- List of papers with videos based on Pinocchio

TODO
