# Handling the sparsity
