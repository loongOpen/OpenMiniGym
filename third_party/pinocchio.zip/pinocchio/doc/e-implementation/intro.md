# Implementation / Technical details
