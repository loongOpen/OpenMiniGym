#include "pinocchio/parsers/urdf.hpp"
#include "pinocchio/algorithm/joint-configuration.hpp"
#include "pinocchio/algorithm/jacobian.hpp"
#include "pinocchio/algorithm/kinematics.hpp"

#include "log_pinRefined.h"

#include <iostream>

Eigen::Matrix<double,3,3> eul2Rot(double roll, double pitch, double yaw); // 欧拉角转旋转矩阵，ZYX顺序

int main(int argc, char ** argv)
{
    std::cout<<"------------------ big biped ------------------"<<std::endl;
    // 导入urdf模型，初始化数据容器
    const std::string urdf_robot_filename = std::string("../panda_man_v2.urdf");
    pinocchio::Model model_biped;
    pinocchio::urdf::buildModel(urdf_robot_filename, model_biped);
    pinocchio::Data data_biped(model_biped);

    auto r_ankle_Joint=model_biped.getJointId("J_R5");
    auto l_ankle_Joint=model_biped.getJointId("J_L5");

    Eigen::Matrix3d Rdes;
    Rdes<<0,0,-1,
            -1,0,0,
            0,1,0; // note for the current URDF, the foot-end coordinate does NOT align with the one of the baselink
    Eigen::Vector3d Pdes;
    Pdes<<0.1,0.1,-0.9;  // for left leg

    // assign proper ini value!!!
    Eigen::VectorXd q = Eigen::VectorXd::Zero(model_biped.nv);
    q(3)=0.1;
    q(9)=0.1;

    const double eps  = 1e-4;
    const int IT_MAX  = 1000;
    const double DT   = 8e-1;
    const double damp = 1e-3;

    Eigen::MatrixXd J(6,model_biped.nv);
    J.setZero();

    bool success = false;
    Eigen::Matrix<double,6,1> err;
    Eigen::VectorXd v(model_biped.nv);

    int itr_count{0};

    /// eigen-based pinocchio
    q= Eigen::VectorXd::Zero(model_biped.nv);
    q(3)=0.1;
    q(9)=0.1;
    for (itr_count=0;itr_count<IT_MAX; itr_count++)
    {
        // REPLACE THIS SEGMENT ONLY
        pinocchio::forwardKinematics(model_biped,data_biped,q);
        pinocchio::computeJointJacobian(model_biped,data_biped,q,l_ankle_Joint,J);  // J MUST BE in LOCAL joint frame !!!!
        pinocchio::SE3 oMcur=data_biped.oMi[l_ankle_Joint];
        Eigen::Matrix3d RCur=oMcur.rotation();
        Eigen::Vector3d pCur=oMcur.translation();
        //

        Eigen::Matrix3d RErr=RCur.transpose()*Rdes;
        Eigen::Vector3d pErr=RCur.transpose()*(Pdes-pCur);

        err = pin_Refined::log6(RErr,pErr);  // in joint frame
        if(err.norm() < eps)
        {
            success = true;
            break;
        }
        if (itr_count >= IT_MAX)
        {
            success = false;
            break;
        }

        Eigen::Matrix<double,6,6> Jlog;
        Jlog.setZero();
        pin_Refined::Jlog6(RErr.transpose(), -RErr.transpose()*pErr, Jlog);
        J = -Jlog * J;
        Eigen::Matrix<double,6,6> JJt;
        JJt.noalias() = J * J.transpose();
        JJt.diagonal().array() += damp;
        v.noalias() = - J.transpose() * JJt.ldlt().solve(err);
        q += v*DT;

        if(!(itr_count % 10))
            std::cout << itr_count << ": error = " << err.transpose() << std::endl;
    }

    if(success)
    {
        std::cout << "Convergence achieved!" << std::endl;
        std::cout<< "itr count= "<<itr_count<<std::endl;
    }
    else
    {
        std::cout << "\nWarning: the iterative algorithm has not reached convergence to the desired precision" << std::endl;
    }

    std::cout << "\nresult: " << q.transpose() << std::endl;
    std::cout << "\nfinal error: " << err.transpose() << std::endl;
}

// get rotation matrix from euler angles in ZYX order
Eigen::Matrix<double, 3, 3> eul2Rot(double roll, double pitch, double yaw) {
    Eigen::Matrix<double,3,3> Rx,Ry,Rz;
    Rz<<cos(yaw),-sin(yaw),0,
            sin(yaw),cos(yaw),0,
            0,0,1;
    Ry<<cos(pitch),0,sin(pitch),
            0,1,0,
            -sin(pitch),0,cos(pitch);
    Rx<<1,0,0,
            0,cos(roll),-sin(roll),
            0,sin(roll),cos(roll);
    return Rz*Ry*Rx;
}